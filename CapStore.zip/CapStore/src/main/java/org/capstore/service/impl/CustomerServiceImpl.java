package org.capstore.service.impl;

import org.capstore.dao.impl.CustomerDaoImpl;
import org.capstore.daointerface.CustomerDaoInterface;
import org.capstore.serviceinterface.CustomerServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.ModelAndView;

public class CustomerServiceImpl implements CustomerServiceInterface {

	
	@Autowired
	CustomerDaoImpl dao;
	
	@Override
	public ModelAndView search() {
	
		return dao.searchCustomer();
		
	}

	
}
