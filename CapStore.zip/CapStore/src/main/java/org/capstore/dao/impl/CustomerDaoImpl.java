package org.capstore.dao.impl;

import org.capstore.daointerface.CustomerDaoInterface;
import org.capstore.serviceinterface.CustomerServiceInterface;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

public class CustomerDaoImpl  implements CustomerDaoInterface{

	@Override
	@RequestMapping("/hello")
	public ModelAndView searchCustomer() {
		System.out.println("Hello Customer");
		String message="Hello Customer";
		return new ModelAndView("helloPage","msg2",message);
	}
	

}
