package org.capstore.controller;

import java.security.Provider.Service;

import org.capstore.daointerface.CustomerDaoInterface;
import org.capstore.service.impl.CustomerServiceImpl;
import org.capstore.serviceinterface.CustomerServiceInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class HelloController {

	@Autowired
	CustomerServiceImpl service;
	
	@Autowired
	CustomerDaoInterface dao;
	
	
	
	@RequestMapping("/hello")
	public ModelAndView sayHello(){
		//String message="Hello Spring MVC";
		service.search();

		return service.search();
	}
	
	
	
	
	
}
